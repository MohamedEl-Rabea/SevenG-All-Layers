<?php

require_once('persian_log2vis.php');

if(!isset($_POST['text'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> أدخل اسمك:برمجه 7G</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <style>
        body{
            background-image: url(bac.jpg);
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-size: cover;
             
        }
        input{
            direction:rtl;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
       <br>
        <div class="offset-md-3 col-md-7">
            <h3 class="alert alert-info text-center">مبارك عليكم الشهر .... من فضلك ادخل اسمك</h3>
             <form method="POST" action="">
    <div class="form-group">
  <label for="usr">Add Your Name:</label>
  <input required type="text" placeholder="أسمك هنا" name="text" class="form-control btn-lg" id="usr">
</div>
<div class="form-group">
  <input type="submit" name="sub" value="ابدء الان" class="form-control btn btn-danger btn-lg" >
</div>

    </form>
        </div>
       
    </div>
    
</div>
   
</body>
</html>
<?
}else{
   function generateRandomString($length = 20) {
	return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
    $text = $_POST['text'];
    persian_log2vis($text);
    
    // Create the image  
    $imgPath = '1.png';
    $im = imagecreatefrompng($imgPath); 
    
    // Create some colors
    $white = imagecolorallocate($im, 255, 255, 255);
    $black = imagecolorallocate($im, 0, 0, 0);
    
    // Replace path by your own font path
    $font = 'JannaLT-Regular.ttf';
    
    // Add the text
    @imagettftext($im, 40, 0, 600, 800,  $black, $font, $text);
  
   

    // Set the content-type
    //header("Content-type: image/png");
    $rand= generateRandomString();
    //imagepng($im);
    imagepng($im, "img/".$rand.".png");
    header("Location: img/$rand.png");
    imagedestroy($im);
     
}


?>

